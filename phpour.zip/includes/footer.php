<script src="vendor/jquery/jquery.min.js"></script>

<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<script src="vendor/slick/slick.min.js"></script>

<script src="js/osahan.js"></script>

<script src="js/rocket-loader.min.js" data-cf-settings="5df22122ad34e02e62e862c4-|49" defer></script>
